package edad;

import java.util.Scanner;

public class AppCaledad {

	public static void datosgenerales(int dia,int mes,int ano)
    {
    	System.out.println("**************************************************");
		System.out.println("* Universidad distrital Francisco José de Caldas *");
		System.out.println("* Ingeniería Electrica                           *");
		System.out.println("* 007-741 Programación Orientada a Objetos       *");
        System.out.println("* José Nicolás Cervantes Castro 20232007088      *");
        System.out.println("* Oscar Daniel Gil 20232007095                   *");
		System.out.println("* "+dia+" de "+mes+" de "+ano+"                                *");
		System.out.println("**************************************************");
    }
	
	public static int edad (int anoa,int anon) {
		int edad = anoa - anon;
		return edad;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int dia = 07, mes = 03,ano_actual=2024;
		datosgenerales(dia,mes,ano_actual);
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ingrese su año de nacimiento: ");
		int ano_nacimiento = scanner.nextInt();
		int edad = edad(ano_actual,ano_nacimiento);
		System.out.println("Usted tiene "+ edad + " años.");
		
	}

}
